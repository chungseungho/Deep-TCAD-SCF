"""Constant-memory adaptive Gauss integration with an observable error budget.

A coarse streaming pass sets the componentwise target. Each initial resonance
panel gets an equal share, recursively split between children. Accepted sums
and estimated errors are accumulated immediately: memory is O(one energy batch
plus one integral vector), independent of the number of panels. A q/2q estimate
is not a proof against missed peaks; independent resonance guidance is required.
"""
import numpy as np
from numpy.polynomial.legendre import leggauss


def integrate_vector(fun,breaks,order,rtol,atol,max_nodes=60000):
    breaks=np.asarray(breaks);nodes=0;accepted_panels=0
    if len(breaks)<2 or np.any(np.diff(breaks)<=0):raise ValueError('Strictly increasing energy breaks required')
    rules={}
    for q in (order,2*order):
        x,w=leggauss(q);angle=np.pi*(x+1)/4
        rules[q]=(np.sin(angle)**2,w*(np.pi/4)*np.sin(2*angle))
    def panel(a,b,q):
        nonlocal nodes
        if nodes+q>max_nodes:raise RuntimeError(f'Energy integration exhausted {max_nodes} GF nodes; increase integration budget, not SCF tolerance')
        x,w=rules[q];e=a+(b-a)*x;nodes+=q;value=None
        for start in range(0,q,16):
            end=min(q,start+16);part=np.einsum('e,ek->k',w[start:end]*(b-a),fun(e[start:end]),optimize=True)
            value=part if value is None else value+part
        return value
    estimate=None
    for a,b in zip(breaks[:-1],breaks[1:]):
        value=panel(a,b,order);estimate=value if estimate is None else estimate+value
    target=np.asarray(atol)+rtol*abs(estimate);initial_panels=len(breaks)-1
    for attempt in range(3):
        total=np.zeros_like(estimate);error_sum=np.zeros_like(abs(estimate));accepted_panels=0
        for a,b in zip(breaks[:-1],breaks[1:]):
            stack=[(a,b,0,target/initial_panels)]
            while stack:
                a,b,level,budget=stack.pop();lo=panel(a,b,order);hi=panel(a,b,2*order);error=abs(hi-lo)
                if np.all(error<=budget):
                    total+=hi;error_sum+=error;accepted_panels+=1;continue
                middle=(a+b)/2
                if level>=44 or middle==a or middle==b:
                    raise RuntimeError('UNRESOLVED_RESONANCE: local error budget not resolved; no artificial broadening')
                stack.append((middle,b,level+1,budget*.5));stack.append((a,middle,level+1,budget*.5))
        final_target=np.asarray(atol)+rtol*abs(total)
        if np.all(error_sum<=final_target):
            return total,{'gf_nodes':nodes,'adaptive_panels':accepted_panels,
                'initial_panels':initial_panels,'maximum_normalized_error_estimate':float(np.max(error_sum/final_target)),
                'algorithm':'streaming coarse target plus recursively budgeted q/2q panels',
                'energy_batch_limit':16,'stored_panel_density_vectors':0}
        target=np.minimum(target,final_target)*.9
    raise RuntimeError('Energy quadrature did not meet its final observable budget')
