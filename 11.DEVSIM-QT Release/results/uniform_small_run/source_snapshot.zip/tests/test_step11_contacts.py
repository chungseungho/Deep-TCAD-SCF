import numpy as np
from numpy.testing import assert_allclose
from dataclasses import replace
from config import Config,Valley
from modespace.hamiltonian import Grid
from modespace.junction_basis import JunctionCompatibleBuilder
from transport.contact_model import solve_reference,transverse_laplacian
from transport.negf_reference import lead_matrices,rgf,device_blocks,solve_negf
from validation.analytical import chain


def test_reference_neutrality_gauge_and_actual_rotated_coupling():
    c=Config(geometry_profile='uniform',width=2,thickness=2,sd_width=2,sd_thickness=2,dy=1,dz=1,modes=2,sd_modes=2)
    g=Grid.build(c);v=Valley('test',.19,.19,.916,2);r=solve_reference(c,g,[v])
    assert r.diagnostics['neutrality_relative_error']<1e-10
    assert max(abs(transverse_laplacian(2,2,1,1)@r.phi-1.602176634e-19*1e-14/(8.8541878128e-14*c.eps_si)*(c.donor_sd-r.density)))<1e-9
    b=JunctionCompatibleBuilder(c,g,v);b.contacts=r;b.block_only=True;s=b.build(np.tile(r.phi,len(g.x)))
    ons,hop,t,lead=device_blocks(s,c,(0,0));energy=.8+.02j
    actual=lead_matrices(np.array([energy]),t,lead)[0][0]
    e,u,tx=r.spectra[v.name];U=s.bases[0][g.mask[0]]
    from transport.negf_reference import surface_sigma
    V=-tx*U.T@u;gs=np.diag(surface_sigma([energy],e+2*tx,tx)[0]/tx**2)
    assert_allclose(actual,V@gs@V.T,atol=1e-14)
    assert s.H is None


def test_cut_invariance_rotated_multichannel_density_and_transmission():
    # Same open two-channel Hamiltonian; add ideal layers on either end, then
    # compare the identical central region. Complex z tests spectral density.
    t=.3;eps=np.array([.2,.45]);ang=.41;U=np.array([[np.cos(ang),-np.sin(ang)],[np.sin(ang),np.cos(ang)]])
    lead=[(eps,U),(eps,U)];E=np.array([.29,.37,.61]);z=E+.001j
    H=U@np.diag(eps)@U.T;barrier=np.array([[.07,.01],[.01,.02]])
    values=[]
    for padding in (0,1,4):
        ons=[H.copy() for _ in range(5+2*padding)];ons[padding+2]+=barrier
        hop=[-t*np.eye(2) for _ in range(len(ons)-1)];sl,sr=lead_matrices(z,t,lead)
        G,_=rgf(z,ons,hop,sl,sr)
        sl,sr=lead_matrices(E,t,lead);_,A=rgf(E,ons,hop,sl,sr,False,0)
        gam=1j*(sr-sr.conj().transpose(0,2,1));T=np.einsum('eij,ejk,eik->e',gam,A[-1],A[-1].conj()).real
        values.append((np.array(G[padding:padding+5]),np.array(A[padding:padding+5])@np.array(A[padding:padding+5]).conj().transpose(0,1,3,2),T))
    for v in values[1:]:
        for a,b in zip(values[0],v):assert_allclose(a,b,rtol=1e-10,atol=1e-11)


def test_left_right_contour_same_density_without_isolated_states():
    c,s,e=chain(n=9,barrier=.05);mu=e+.14;vd=.04
    left=solve_negf(s,replace(c,density_reference='left'),mu,mu-vd,vd)
    right=solve_negf(s,replace(c,density_reference='right'),mu,mu-vd,vd)
    assert_allclose(left[0],right[0],atol=2e-8,rtol=2e-7)
    assert_allclose(left[1],right[1],atol=1e-13,rtol=1e-7)
